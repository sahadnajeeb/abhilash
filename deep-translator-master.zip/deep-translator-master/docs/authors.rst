=======
Credits
=======

Development Lead
----------------

* Nidhal Baccouri <nidhalbacc@gmail.com>

Contributors
------------

@prataffel
@senk8
@nothead31