deep\_translator package
========================

Submodules
----------

deep\_translator.base module
----------------------------

.. automodule:: deep_translator.base
   :members:
   :undoc-members:
   :show-inheritance:

deep\_translator.cli module
---------------------------

.. automodule:: deep_translator.cli
   :members:
   :undoc-members:
   :show-inheritance:

deep\_translator.constants module
---------------------------------

.. automodule:: deep_translator.constants
   :members:
   :undoc-members:
   :show-inheritance:

deep\_translator.deepl module
-----------------------------

.. automodule:: deep_translator.deepl
   :members:
   :undoc-members:
   :show-inheritance:

deep\_translator.detection module
---------------------------------

.. automodule:: deep_translator.detection
   :members:
   :undoc-members:
   :show-inheritance:

deep\_translator.engines module
-------------------------------

.. automodule:: deep_translator.engines
   :members:
   :undoc-members:
   :show-inheritance:

deep\_translator.exceptions module
----------------------------------

.. automodule:: deep_translator.exceptions
   :members:
   :undoc-members:
   :show-inheritance:

deep\_translator.google module
------------------------------

.. automodule:: deep_translator.google
   :members:
   :undoc-members:
   :show-inheritance:

deep\_translator.libre module
-----------------------------

.. automodule:: deep_translator.libre
   :members:
   :undoc-members:
   :show-inheritance:

deep\_translator.linguee module
-------------------------------

.. automodule:: deep_translator.linguee
   :members:
   :undoc-members:
   :show-inheritance:

deep\_translator.microsoft module
---------------------------------

.. automodule:: deep_translator.microsoft
   :members:
   :undoc-members:
   :show-inheritance:

deep\_translator.mymemory module
--------------------------------

.. automodule:: deep_translator.mymemory
   :members:
   :undoc-members:
   :show-inheritance:

deep\_translator.papago module
------------------------------

.. automodule:: deep_translator.papago
   :members:
   :undoc-members:
   :show-inheritance:

deep\_translator.pons module
----------------------------

.. automodule:: deep_translator.pons
   :members:
   :undoc-members:
   :show-inheritance:

deep\_translator.qcri module
----------------------------

.. automodule:: deep_translator.qcri
   :members:
   :undoc-members:
   :show-inheritance:

deep\_translator.validate module
--------------------------------

.. automodule:: deep_translator.validate
   :members:
   :undoc-members:
   :show-inheritance:

deep\_translator.yandex module
------------------------------

.. automodule:: deep_translator.yandex
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: deep_translator
   :members:
   :undoc-members:
   :show-inheritance:
