from deep_translator import MyMemoryTranslator

res = MyMemoryTranslator(source="ar", target="en").translate("آخُذ اَلْباص.")

print(res)
